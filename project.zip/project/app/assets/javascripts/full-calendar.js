var intialize_calendar;
initialize_calendar = function(){
  $('.calendar').each(function(){
    var calendar = $(this)
    calendar.fullcalendar({});
  })
};
$(document).on('turbolinks:load', initialize_calendar);
