class RequestsController < ApplicationController
  def form
  end

  def view
      @requests = Request.all
  end

  def index
    @request = Request.all
  end

  def officials
    @request = Request.all
  end

  def officials_view
    @requests = Request.find(params[:id])
  end

  def new_official
    @request = Request.new()
  end

  def add_official
    @request = Request.new()
    @request.first_name = params[:request][:first_name]
    @request.middle_name = params[:request][:middle_name]
    @request.last_name = params[:request][:last_name]
    @request.position = params[:request][:position]
    @request.save
    redirect_to "/requests/officials_view/#{@request.id}"
  end

  def edit
  end
end
