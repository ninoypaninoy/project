Rails.application.routes.draw do
  get 'requests/form'

  get 'requests/view' => 'requests#view'

  get 'requests' => 'requests#index'

  get 'requests/edit'

  get 'requests/officials' => 'requests#officials'

  get 'requests/officials_view/:id' => 'requests#officials'

  get 'requests/new_official' => 'requests#new_official'

  post 'requests' => 'requests#add_official'

  get "log_out" => "sessions#destroy", :as => "log_out"
  get "log_in" => "sessions#new", :as => "log_in"
  get "sign_up" => "users#new", :as => "sign_up"

  root :to => "users#new"
  resources :users
  resources :sessions
end
